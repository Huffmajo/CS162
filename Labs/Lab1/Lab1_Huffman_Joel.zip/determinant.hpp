#ifndef determinant_hpp
#define determinant_hpp

int determinant(int** ptr, int matrixSize);

#endif /* determinant_hpp */
