#ifndef readMatrix_hpp
#define readMatrix_hpp

void readMatrix(int** pointerToMatrix, int matrixSize);

#endif /* readMatrix_hpp */
