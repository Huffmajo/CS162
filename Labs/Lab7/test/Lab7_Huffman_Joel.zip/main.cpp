/*********************************************************************
 ** Program name: Circular-linked List
 ** Author: Joel Huffman
 ** Date: 2/19/2018
 ** Description: Allows users to add, delete and print out nodes of a
 ** circular-linked list
 *********************************************************************/

#include "utils.hpp"

int main() {
    
    menu();
    
    return 0;
}
